#include <avr/io.h>
#include <avr/ioavr128db48.h>
#include <avr/interrupt.h>


void rtc_init(uint16_t compare, uint16_t period, uint16_t interrupt, uint16_t prescale_en, uint16_t enable) {
   while (RTC.STATUS && RTC.PITSTATUS) {
        ; // wait until RTC is not busy
    }
    if (compare) {
        RTC.CMP = compare;
    } else {
        RTC.CMP = period; // Default max compare value
    }
    RTC.INTCTRL = interrupt; // Enable interrupt
    RTC.CTRLA = prescale_en | enable; // Set prescaler and enable RTC

}