#ifndef AOS_TIMER_H_
#define AOS_TIMER_H_

#include <avr/io.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Callback signature for TCA1 overflow events
typedef void (*aos_tca1_callback_t)(void);

// Configure TCA1 for 1ms tick at 16MHz with DIV64 (PER=249) by default
// You can call aos_tca1_configure with custom parameters before enabling.
void aos_tca1_configure(uint16_t per_value, uint8_t ctrla_flags, uint8_t ctrlb_flags);

// Register/unregister the TCA1 overflow callback. Pass NULL to unregister.
void aos_tca1_register(aos_tca1_callback_t cb);
void aos_tca1_unregister(void);

// Enable/disable the TCA1 overflow interrupt and timer
void aos_tca1_enable(void);
void aos_tca1_disable(void);

// Convenience: start with common 1ms configuration (PER=249, DIV64)
static inline void aos_tca1_start_1ms(void) {
  aos_tca1_configure(249, TCA_SINGLE_CLKSEL_DIV64_gc | TCA_SINGLE_ENABLE_bm, TCA_SINGLE_WGMODE_NORMAL_gc);
  aos_tca1_enable();
}

#ifdef __cplusplus
}
#endif

#endif /* AOS_TIMER_H_ */
