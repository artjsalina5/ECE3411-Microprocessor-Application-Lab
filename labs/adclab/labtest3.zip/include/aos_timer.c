#define F_CPU 16000000UL
#define __AVR_AVR128DB48__
#include "aos_timer.h"
#include <avr/interrupt.h>

// Single global callback for TCA1 dispatch
static volatile aos_tca1_callback_t s_tca1_cb = 0;

void aos_tca1_configure(uint16_t per_value, uint8_t ctrla_flags, uint8_t ctrlb_flags) {
  // Put timer in known state
  TCA1.SINGLE.CTRLA = 0; // disable while reconfiguring
  TCA1.SINGLE.CTRLB = ctrlb_flags;
  TCA1.SINGLE.PER = per_value;

  // Do not enable INTCTRL here; aos_tca1_enable controls that
  TCA1.SINGLE.INTCTRL = 0; 

  // Apply clock selection and enable flag if present
  TCA1.SINGLE.CTRLA = ctrla_flags & (TCA_SINGLE_ENABLE_bm | TCA_SINGLE_CLKSEL_gm);
}

void aos_tca1_register(aos_tca1_callback_t cb) {
  s_tca1_cb = cb;
}

void aos_tca1_unregister(void) {
  s_tca1_cb = 0;
}

void aos_tca1_enable(void) {
  // Clear any pending flag
  TCA1.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
  // Enable overflow interrupt
  TCA1.SINGLE.INTCTRL |= TCA_SINGLE_OVF_bm;
}

void aos_tca1_disable(void) {
  // Disable overflow interrupt and stop timer
  TCA1.SINGLE.INTCTRL &= ~TCA_SINGLE_OVF_bm;
  TCA1.SINGLE.CTRLA &= ~TCA_SINGLE_ENABLE_bm;
  // Clear any pending flag
  TCA1.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}

ISR(TCA1_OVF_vect) {
  // Dispatch to registered callback if present
  aos_tca1_callback_t cb = s_tca1_cb;
  if (cb) {
    cb();
  }
  // Clear the overflow flag
  TCA1.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
}
