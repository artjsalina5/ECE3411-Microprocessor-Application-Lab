/**
 * @file melody.h
 * @author Arturo Salinas
 * @date 2025-11-02
 * @brief Melody player using DAC output
 */

#ifndef MELODY_H_
#define MELODY_H_

#include <stdint.h>
#include <stddef.h>

// Note definitions (frequencies in Hz)
#define E4  330
#define A4  440
#define Cb5 554
#define B4  494
#define Gb4 415
#define Fb4 370
#define Db4 311
#define D5  587
#define E5  659

// Note structure: {frequency, duration_ms, pause_after_ms}
typedef struct {
    uint16_t frequency;
    uint16_t duration;
    uint16_t pause;
} melody_note_t;

// MIDI melody definition
extern const melody_note_t midi1[81];
extern const size_t midi1_length;

/**
 * @brief Initialize melody player
 */
void melody_init(void);

/**
 * @brief Play a single note at specified frequency
 * @param frequency Frequency in Hz (0 to stop)
 */
void melody_tone(uint16_t frequency);

/**
 * @brief Stop playing tone
 */
void melody_no_tone(void);

/**
 * @brief Play entire melody (blocking)
 * @param notes Array of melody notes
 * @param length Number of notes in melody
 */
void melody_play(const melody_note_t *notes, size_t length);

/**
 * @brief Check if melody is currently playing
 * @return true if playing, false otherwise
 */
bool melody_is_playing(void);

/**
 * @brief Set playback speed multiplier (tempo)
 * @param multiplier 1 = normal, 2 = 2x faster (half durations), etc. Minimum is 1.
 */
void melody_set_speed(uint8_t multiplier);

#endif /* MELODY_H_ */
